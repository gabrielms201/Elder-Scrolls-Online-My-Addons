local u = HodorReflexes.users
local a = HodorReflexes.anim.users

u["@Floliroy"] = {"Floliroy", "Floliroy", "HodorReflexes/users/frenchkiss/Oppression.dds"}
u["@Nicojob"] = {"Nicojob", "Nicojob", "HodorReflexes/users/frenchkiss/aAa.dds"}
u["@Hylda69"] = {"Hylda", "Hylda", "HodorReflexes/users/frenchkiss/NotSure.dds"}
u["@Panaa"] = {"Panaa", "Panaa", "HodorReflexes/users/frenchkiss/HI.dds"}
u["@Freezedm"] = {"Freez", "Freez", "HodorReflexes/users/frenchkiss/Freez.dds"}
u["@MehrunesDagon3"] = {"Mehrune", "Mehrune", "HodorReflexes/users/frenchkiss/Mehru.dds"}
u["@Reiigone"] = {"Reiigone", "Reiigone", "HodorReflexes/users/frenchkiss/Reiigone.dds"}
u["@Elhann"] = {"Elhan", "Elhan", "HodorReflexes/users/frenchkiss/Elhan.dds"}
u["@JahgobaEU"] = {"Jahgoba", "Jahgoba", "HodorReflexes/users/frenchkiss/Jahgo.dds"}
u["@Harlyne"] = {"Harlyne", "Harlyne", "HodorReflexes/users/frenchkiss/Harlyne.dds"}
u["@Mourtou"] = {"Mourtou", "Mourtou", "HodorReflexes/users/frenchkiss/Mourtou.dds"}
u["@Rider07"] = {"Rider", "Rider", "HodorReflexes/users/frenchkiss/Rider.dds"}
u["@Msaat"] = {"Msaat", "Msaat", "HodorReflexes/users/frenchkiss/OOF.dds"}
u["@Izaki"] = {"Izaki", "Izaki", "HodorReflexes/users/frenchkiss/Naruto.dds"}

a["@Floliroy"] = {"HodorReflexes/users/frenchkiss/floliroy_anim.dds", 10, 1, 10}
