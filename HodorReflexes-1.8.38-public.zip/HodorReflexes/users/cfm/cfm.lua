local u = HodorReflexes.users
local a = HodorReflexes.anim.users

u["@FALK24680"] = {"Falk", "|c155196Falk|r", "HodorReflexes/users/cfm/FALK24680.dds"}
u["@haruna742"] = {"Haru", "|cd420c8H|r|ce336d6a|r|cf14de3r|r|cff63f1u|r", "HodorReflexes/users/cfm/haruna742.dds"}
u["@JackRazor"] = {"Jack", "|cfbb703Jack|r", "HodorReflexes/users/cfm/JackRazor.dds"}
u["@KS_Amt38"] = {"KS", "|cae2f2fK|r|c5d5d5dS|r", "HodorReflexes/users/cfm/KS_Amt38.dds"}
u["@looc2212"] = {"Looc", "|ca8a8a8L|r|c0c00ffoo|r|cc6241bc|r", "HodorReflexes/users/cfm/looc2212.dds"}
u["@Noneatza"] = {"Nonel", "|cff1100Nonel|r", "HodorReflexes/users/cfm/Noneatza.dds"}
u["@Siegfried24"] = {"Siggi", "|c17b200Siggi|r", "HodorReflexes/users/cfm/Siegfried24.dds"}
u["@Solowith"] = {"Solo", "|cff06e6Solo|r", "HodorReflexes/users/cfm/Solowith.dds"}
u["@Tisi214"] = {"Tisi", "|c000000Tisi|r", "HodorReflexes/users/cfm/Tisi214.dds"}
u["@FlaminDemigod"] = {"Flamin", "|cff8300Flamin|r", "HodorReflexes/users/cfm/FlaminDemigod.dds"}

a["@FlaminDemigod"] = {"HodorReflexes/users/cfm/FlaminDemigod_anim.dds", 25, 1, 24}