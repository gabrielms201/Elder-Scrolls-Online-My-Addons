local u = HodorReflexes.users
local a = HodorReflexes.anim.users

u["@Hricine"] = {"Hricine", "|c32ffffHricine|r", "HodorReflexes/users/pushdeeps/hricine.dds"}
u["@esco1337"] = {"Esco", "|cff0013Esco|r", "HodorReflexes/users/pushdeeps/esco1337.dds"}
u["@Shinji-AT78"] = {"Shinji", "|c4e79ffShinji|r", "HodorReflexes/users/pushdeeps/Shinji-AT78.dds"}
u["@Norval666"] = {"Norval", "|cff0000Norval|r", "HodorReflexes/users/pushdeeps/Norval666.dds"}
u["@MouqMouq"] = {"MouqMouq", "|c00ffa2MouqMouq|r", "HodorReflexes/users/pushdeeps/MouqMouq.dds"}